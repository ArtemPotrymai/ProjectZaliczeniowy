import java.io.*;
import java.net.*;
import java.util.List;
import java.util.Scanner;

public class Klient {
    private static final String HOST = "localhost";
    private static final int PORT = 12345;

    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java Klient <client_id>");
            return;
        }

        int clientId;
        try {
            clientId = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.out.println("Invalid client ID. Please provide an integer.");
            return;
        }

        try (Socket socket = new Socket(HOST, PORT);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            out.writeInt(clientId);
            out.flush();

            String status = (String) in.readObject();
            if ("REFUSED".equals(status)) {
                System.out.println("Client " + clientId + ": Connection refused");
                return;
            }

            System.out.println("Client " + clientId + ": Connected with status " + status);

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("Enter the class you want to request (Kot, Pies, Ptak) or 'exit' to disconnect:");
                String userInput = scanner.nextLine();

                if (userInput.equalsIgnoreCase("exit")) {
                    out.writeObject("exit");
                    out.flush();
                    System.out.println("Client " + clientId + ": Disconnected from server");
                    break;
                }

                String request = "get_" + userInput;
                out.writeObject(request);
                out.flush();

                try {
                    List<Object> objects = (List<Object>) in.readObject();
                    System.out.println("Client " + clientId + " received: " + objects);
                } catch (ClassCastException e) {
                    System.out.println("Client " + clientId + " received unexpected object type");
                }
            }

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
