import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

class Kot implements Serializable {
    private String name;

    public Kot(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Kot{" + "name='" + name + '\'' + '}';
    }
}

class Pies implements Serializable {
    private String name;

    public Pies(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Pies{" + "name='" + name + '\'' + '}';
    }
}

class Ptak implements Serializable {
    private String name;

    public Ptak(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Ptak{" + "name='" + name + '\'' + '}';
    }
}

public class Serwer {
    private static final int PORT = 12345;
    private static final int MAX_CLIENTS = 5;
    private static Map<String, List<Object>> objectMap = new HashMap<>();
    private static Set<Integer> connectedClients = new HashSet<>();
    private static ExecutorService executorService = Executors.newFixedThreadPool(MAX_CLIENTS);

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(PORT);
        System.out.println("Serwer uruchomiony na porcie: " + PORT);
        initializeObjects();

        while (true) {
            Socket clientSocket = serverSocket.accept();
            executorService.execute(new ClientHandler(clientSocket));
        }
    }

    private static void initializeObjects() {
        List<Object> koty = Arrays.asList(new Kot("Kot_1"), new Kot("Kot_2"), new Kot("Kot_3"), new Kot("Kot_4"));
        List<Object> psy = Arrays.asList(new Pies("Pies_1"), new Pies("Pies_2"), new Pies("Pies_3"), new Pies("Pies_4"));
        List<Object> ptaki = Arrays.asList(new Ptak("Ptak_1"), new Ptak("Ptak_2"), new Ptak("Ptak_3"), new Ptak("Ptak_4"));

        objectMap.put("kot", koty);
        objectMap.put("pies", psy);
        objectMap.put("ptak", ptaki);
    }

    private static class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
                 ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream())) {

                int clientId = in.readInt();
                if (connectedClients.size() >= MAX_CLIENTS) {
                    out.writeObject("REFUSED");
                    System.out.println("Client " + clientId + " refused");
                    return;
                }

                connectedClients.add(clientId);
                out.writeObject("OK");
                System.out.println("Client " + clientId + " connected");

                while (true) {
                    String request = (String) in.readObject();
                    if (request.equals("exit")) {
                        break;
                    }

                    String objectType = request.split("_")[1].toLowerCase();

                    if (objectMap.containsKey(objectType)) {
                        List<Object> objects = objectMap.get(objectType);
                        out.writeObject(objects);
                        System.out.println("Sent " + objects.size() + " " + objectType + " objects to client " + clientId);
                    } else {
                        out.writeObject(Collections.singletonList(new Pies("Default_Pies")));
                        System.out.println("Sent default Pies object to client " + clientId);
                    }

                    // Simulate random delay
                    Thread.sleep(new Random().nextInt(1000));
                }

                connectedClients.remove(clientId);
                System.out.println("Client " + clientId + " disconnected");

            } catch (IOException | ClassNotFoundException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
